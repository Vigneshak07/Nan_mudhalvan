Steps to run our project:

.First we have created an workspace in ths Google colab 

.Then mounted our Data Set which we got from the IBM 

.we have then imported the necessary packages for our project

.Then we haved printed the Head() ie(First 5 rows of our dataset to loook after)

.we have eleminated the null values from our dataset

.After we have used the plot() to plot the corelation of our data

.At last after all these we have trained our project model and tested it with different values as input

.We have recived the prediction for our product demand.

Dependencies:
.pandas
.numpy
.plotly.express
.seaborn
.matplotlib.pyplot
.sklearn.model_selection - train_test_split
. sklearn.tree - DecisionTreeRegressor
